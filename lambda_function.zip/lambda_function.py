import json
import boto3
import requests
import bs4
import requests,datetime
from bs4 import BeautifulSoup
import re
import cred
from cred import AWS_SERVER_PUBLIC_KEY,AWS_SERVER_SECRET_KEY
import datetime
import pandas as pd
import io
from io import StringIO
import numpy as np

#Main handler/Controller of the program
def lambda_handler(event, context):
    # TODO implement
    if event != '':

        #Establish s3 session
        s3 = s3Connection()
  
        BUCKET_NAME = "scrape-filedrop"
        DEST_BUCKET_NAME = 'scrape-searchresults'
    
        #Parsing the dropped file
        MostRecentFile = fetchDroppedFile(BUCKET_NAME, s3)

        s3 = boto3.resource('s3')
             
        
        for i in MostRecentFile.index:
            # ct stores current time
            ct = datetime.datetime.now()
            OUTPUT_NAME = MostRecentFile["searchword"][i] + str(ct) + ".csv"

            #The results of the google search
            searchresults = scrapeGlobalCase(MostRecentFile["searchword"][i])
            OUTPUT_BODY = searchresults

            print (f"[INFO] Saving Data to S3 {BUCKET_NAME} Bucket...")
            #s3.Bucket(DEST_BUCKET_NAME).put_object(Key=OUTPUT_NAME, Body=OUTPUT_BODY)

            object = s3.Object(DEST_BUCKET_NAME, OUTPUT_NAME)
            object.put(Body=OUTPUT_BODY) 
        

#Look for the searchword in a Google search
def scrapeGlobalCase (searchword):
    
    try:
        # Google search url, concatenate with the searchword to get the correct search url
        url = 'https://google.com/search?q=' + searchword

        # Fetch the URL data using requests.get(url)
        request_result=requests.get( url )

        # Creating soup from the fetched request
        soup = bs4.BeautifulSoup(request_result.text,
                                "html.parser")
        
    except Exception as e: print(e)

    arraylist = ""
    for link in soup.find_all('a', attrs={'href': re.compile("^https://")}):
        # display the actual urls
        #print(link.get('href'))
        arraylist = arraylist + link.get('href') + "\n"
    return arraylist
        
#Fetch the most recent dropped file for processing
def fetchDroppedFile (bucket_name, s3):
    
    get_last_modified = lambda obj: int(obj['LastModified'].strftime('%s'))
    objs = s3.list_objects_v2(Bucket=bucket_name)['Contents']
    last_added = [obj['Key'] for obj in sorted(objs, key=get_last_modified)][-1]

    obj = s3.get_object(Bucket=bucket_name, Key=last_added)
    mostRecentFile = pd.read_csv(obj['Body'], error_bad_lines=False)
    print(mostRecentFile)
    mostRecentFile.columns = {"searchword"}
    mostRecentFile['searchword'].replace("'", '')
    mostRecentFile['searchword'].str.strip()

    return mostRecentFile

#Establish an S3 session
def s3Connection():

    #Initializing connection to s3
    s3 = boto3.client(
    service_name='s3',
    region_name='ap-south-1',
    aws_access_key_id=AWS_SERVER_PUBLIC_KEY,
    aws_secret_access_key=AWS_SERVER_SECRET_KEY
    )
    
    return s3

